﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_11
{
    internal class Program
    {
        static void Main(string[] args)
        {

            {
                Pessoa peso;
                peso = new Pessoa();

                Console.WriteLine("Digite a altura");
                peso.setAlt(double.Parse(Console.ReadLine()));

                Console.WriteLine("Digite o peso");
                peso.setPeso(double.Parse(Console.ReadLine()));
                
                peso.calcularRelacao();

                peso.definirPesoIdeal();

            }
        }
    }
}

