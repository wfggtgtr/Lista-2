﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_11
{
    internal class Pessoa
    {
        private double alt;
        private double peso;
        private double r;

        public Pessoa()
        {
            this.alt = 0;
            this.peso = 0;
        }
        public Pessoa(double alt, double peso)
        {
            this.alt = alt;
            this.peso = peso;
        }

        public void setAlt(double alt)
        {
            this.alt = alt;
        }

        public void setPeso(double peso)
        {
            this.peso = peso;
        }

        public double getAlt()
        {
            return this.alt;
        }

        public double getPeso()
        {
            return this.peso;
        }

        public void calcularRelacao()
        {
            r = this.peso / (this.alt * this.alt);
        }

        public void definirPesoIdeal()
        {
            if (r < 20)
            {
                Console.WriteLine("Abaixo do peso");
            }
            else
            {
                if (r >= 20 && r < 25)
                {
                    Console.WriteLine("Peso ideal");
                }
                else
                {
                    Console.WriteLine("Acima do peso");
                }
            }
        }
    }
}

