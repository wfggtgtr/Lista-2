﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excer_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Numero compara;
            compara = new Numero();

            Console.Write("Digite o primeiro valor:");
            compara.setP(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o segundo valor:");
            compara.setS(int.Parse(Console.ReadLine()));
           
            compara.compararNumero();

            Console.WriteLine("O maior valor é: {0}", compara.getMM());
        }
    }
}
