﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Triangulo areat;
            areat = new Triangulo();

            Console.WriteLine("Digite a altura do triângulo");
            areat.setAlt(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite a base do triangulo");
            areat.setBas(int.Parse(Console.ReadLine()));
            
            areat.calcularArea();

            Console.WriteLine("O valor da area do triangulo:{0}", areat.getArea());

        }
    }
}
