﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_4
{
    internal class Triangulo
    {
        private int alt;
        private int bas;
        private int area;

        public Triangulo()
        {
            this.alt = 0;
            this.bas = 0;
        }
        public Triangulo(int alt, int bas)
        {
            this.alt = alt;
            this.bas = bas;
        }
        public void setAlt(int alt)
        {
            this.alt = alt;
        }

        public void setBas(int bas)
        {
            this.bas = bas;
        }

        public int getAlt()
        {
            return this.alt;
        }

        public int getBas()
        {
            return this.bas;
        }
        public int getArea()
        {
            return area;
        }

        public void calcularArea()
        {
            area = (this.bas * this.alt) / 2;

        }
    }
}
