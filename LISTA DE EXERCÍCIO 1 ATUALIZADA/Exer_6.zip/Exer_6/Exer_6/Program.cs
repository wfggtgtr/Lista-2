﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Milha conv;
            conv = new Milha();

            Console.Write("Digite a milha maritmica");
            conv.setMilha(double.Parse(Console.ReadLine()));
            
            conv.converter();

            Console.WriteLine("O valor de {0} milha(s) é {1} quilometros",
            conv.getMilha(), conv.getResultado());
        }
    }
}
