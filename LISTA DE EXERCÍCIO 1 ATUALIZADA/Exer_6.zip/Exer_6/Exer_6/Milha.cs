﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_6
{
    internal class Milha
    {
        private double milha;
        private double km = 1.852;
        private double resultado;

        public Milha ()
        {
            this.milha = 0;
           
        }
        public Milha (double milha)
        {
            this.milha = milha;
        }
        public void setMilha(double milha)
        {
            this.milha = milha;
        }

        public double getMilha()
        {
            return this.milha;
        }

        public double getResultado()
        {
            return resultado;
        }

        public void converter()
        {
            resultado = this.milha * km;
        }
    }
}
