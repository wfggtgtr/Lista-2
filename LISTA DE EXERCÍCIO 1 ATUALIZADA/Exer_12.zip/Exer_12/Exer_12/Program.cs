﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Triangulo tipo;
            tipo = new Triangulo();

            Console.WriteLine("Digite o primeiro lado:");
            tipo.setL1(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o segundo lado:");
            tipo.setL2(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o terceiro lado:");
            tipo.setL3(int.Parse(Console.ReadLine()));

            tipo.compararTriangulo();
        }
    }
}
