﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Retangulo area1;
            area1 = new Retangulo(6,7);

            Console.Write("Digite a base:");
            area1.setA(double.Parse(Console.ReadLine()));

            Console.Write("Digite a altura:");
            area1.setB(double.Parse(Console.ReadLine()));
           
            area1.calcularArea();

            Console.WriteLine("A area do retangulo:{0}",
                area1.getArea());
        }
    }
}
