﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_9
{
    internal class Numero
    {
        private int p;
        private int s;

        public Numero()
        {
            this.p = 0;
            this.s = 0;
        }
        public Numero(int p, int s)
        {
            this.p = p;
            this.s = s;
        }

        public void setP(int p)
        {
            this.p = p;
        }

        public void setS(int s)
        {
            this.s = s;
        }

        public int getP()
        {
            return this.p;
        }

        public int getS()
        {
            return this.s;
        }

        public void compararNumero()
        {
            if (this.p > this.s)
            {
                Console.WriteLine("O maior valor é:{0}", this.p);
            }
            else
            {
                if (this.p == this.s)
                {
                    Console.WriteLine("Os valores são iguais");
                }
                else
                {
                    Console.WriteLine("O maior valor é:{0}", this.s);
                }
            }
        }
    }
}
