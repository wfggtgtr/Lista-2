﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado area1;
            area1 = new Quadrado(5);

            Console.Write("Digite o valor de aresta:");
            area1.setA(int.Parse(Console.ReadLine()));
            
            area1.calcularArea();

            Console.WriteLine("O valor da area e:{0}", area1.getArea());
        }
    }
}
