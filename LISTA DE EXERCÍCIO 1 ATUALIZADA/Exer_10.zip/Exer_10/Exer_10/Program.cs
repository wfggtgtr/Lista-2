﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Retangulo area;
            area = new Retangulo();

            Console.WriteLine("Digite a base");
            area.setB(int.Parse(Console.ReadLine()));

            Console.WriteLine("Digite a altura");
            area.setA(int.Parse(Console.ReadLine()));
            
            area.calcularArea();

            Console.WriteLine("A area é:{0}", area.getArea());

            area.compararArea();
        }
    }
}
