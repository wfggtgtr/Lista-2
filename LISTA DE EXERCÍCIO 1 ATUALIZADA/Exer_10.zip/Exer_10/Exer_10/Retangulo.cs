﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_10
{
    internal class Retangulo
    {
        private int a;
        private int b;
        private int area;

        public Retangulo()
        {
            this.a = 0;
            this.b = 0;
        }
        public Retangulo(int a, int b)
        {
            this.a = a;
            this.b = b;
        }

        public void setA(int a)
        {
            this.a = a;
        }

        public void setB(int b)
        {
            this.b = b;
        }

        public int getA()
        {
            return this.a;
        }

        public int getB()
        {
            return this.b;
        }

        public int getArea()
        {
            return area;
        }

        public void calcularArea()
        {
            area = this.a * this.b;
        }

        public void compararArea()
        {
            if (area > 100)
            {
                Console.WriteLine("Terreno grande");
            }

            else

            {
                Console.WriteLine("Terreno pequeno");
            }
        }
    }
}
