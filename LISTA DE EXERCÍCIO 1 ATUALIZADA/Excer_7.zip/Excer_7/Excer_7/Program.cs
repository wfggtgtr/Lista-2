﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excer_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dinheiro converte;
            converte = new Dinheiro();

            Console.WriteLine("Digite a cotação do dolar:");
            converte.setCota(double.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o valor:");
            converte.setDolar(double.Parse(Console.ReadLine()));
            
            converte.converter();

            Console.WriteLine("Com a cotação em ${0} dólares e o valor que você possui ${1} dólares, o valor em real é: R${2}",
               converte.getCota(), converte.getDolar(), converte.getReal());
        }
    }
}
