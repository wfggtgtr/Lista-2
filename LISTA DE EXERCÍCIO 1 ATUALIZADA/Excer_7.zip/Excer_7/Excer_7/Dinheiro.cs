﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excer_7
{
    internal class Dinheiro
    {
        private double dolar;
        private double cota;
        private double real;
        
        public Dinheiro()
        {
            this.dolar = 0;
            this.cota = 0;
        }
        public Dinheiro (double dolar, double cota)
        {
            this.dolar = dolar;
            this.cota = cota;
        }
        public void setDolar(double dolar)
        {
            this.dolar = dolar;
        }

        public void setCota(double cota)
        {
            this.cota = cota;
        }

        public double getDolar()
        {
            return this.dolar;
        }

        public double getCota()
        {
            return this.cota;
        }

        public double getReal()
        {
            return real;
        }

        public void converter()
        {
            real = this.dolar * this.cota;
        }
    }
}
