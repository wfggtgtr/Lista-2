﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exer_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado diagonal1;
            diagonal1 = new Quadrado(5);

            /*Console.Write("Digite a diagonal do quadrado:");
            diagonal1.setD(int.Parse(Console.ReadLine()));
            */
            diagonal1.calcularArea();

            Console.Write("O valor da area: {0}",
                diagonal1.getArea());
        }
    }
}
